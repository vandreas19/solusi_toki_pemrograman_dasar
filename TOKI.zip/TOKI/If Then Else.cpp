#include <bits/stdc++.h>
using namespace std;
int main(int argc, char const *argv[])
{
	int n;
	scanf("%d", &n);
	if(n>0)printf("positif\n");
	else if(n==0)printf("nol\n");
	else printf("negatif\n");
	return 0;
}