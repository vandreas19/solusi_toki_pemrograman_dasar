#include <bits/stdc++.h>
using namespace std;

int n;
int main(int argc, char const *argv[])
{
	scanf("%d",&n);
	if(n>0)printf("%d\n", n);
	return 0;
}