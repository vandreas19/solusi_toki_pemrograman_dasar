#include <bits/stdc++.h>
using namespace std;

void halo(){
	printf("Halo, dunia!\n");
}

int main(int argc, char const *argv[])
{
	halo();
	return 0;
}