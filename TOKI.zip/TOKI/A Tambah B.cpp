#include <bits/stdc++.h>

using namespace std;

void tambah(int a, int b){
	printf("%d\n",a+b);
}


int a,b;
int main(int argc, char const *argv[])
{
	scanf("%d%d", &a,&b);
	tambah(a,b);
	return 0;
}