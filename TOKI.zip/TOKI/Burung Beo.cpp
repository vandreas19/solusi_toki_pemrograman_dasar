#include <bits/stdc++.h>
using namespace std;


char a[1000];
int main(int argc, char const *argv[])
{
	gets(a);
	printf("%s\n", a);
	return 0;
}